<?php
putenv('GOOGLE_APPLICATION_CREDENTIALS=auth.json');
putenv('FFMpeg=C:\\ffmpeg\\bin\\ffmpeg');
define("BUCKET", "proverbial-cathode-5780");
define("PROJECTID", "graphic-matrix-173618");

